"""
Android Agent Utils

Single-purpose utilities for Android device automation via ADB.
"""

__version__ = "1.0.0"
